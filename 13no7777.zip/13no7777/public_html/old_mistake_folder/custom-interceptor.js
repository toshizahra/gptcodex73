const LOCAL_BACKEND_URL = 'http://localhost:5000';

(function() {
    const originalFetch = window.fetch;
    let localToken = localStorage.getItem('local_auth_token') || null;
    
    window.fetch = async function() {
        let [resource, config] = arguments;
        
        if (typeof resource === 'string') {
            // Intercept Login
            if (resource.includes('/hall/api/account/login/')) {
                console.warn('[INTERCEPTED] Login Call Detected');
                resource = `${LOCAL_BACKEND_URL}/auth/login`;
            }
            // Intercept Register
            else if (resource.includes('/hall/api/account/register/')) {
                console.warn('[INTERCEPTED] Registration Detected');
                resource = `${LOCAL_BACKEND_URL}/auth/register`;
            }
            // Intercept Refresh Profile Data
            else if (resource.includes('/hall/api/account/getUserInfo')) {
                resource = `${LOCAL_BACKEND_URL}/auth/getUserInfo`;
            }
            // Intercept Deposit Requests
            else if (resource.includes('/hall/api/finance/pay/deposit')) {
                console.warn('[INTERCEPTED] Deposit Request Detected');
                if(config && config.body) {
                    const payload = JSON.parse(config.body);
                    resource = `${LOCAL_BACKEND_URL}/wallet/deposit`;
                    config.body = JSON.stringify({
                        amount: payload.amount,
                        payCode: payload.payCode
                    });
                } else {
                    resource = `${LOCAL_BACKEND_URL}/wallet/deposit`;
                }
            }
            // Intercept Withdrawal Requests
            else if (resource.includes('/hall/api/finance/pay/withdraw')) {
                console.warn('[INTERCEPTED] Withdrawal Request Detected');
                if(config && config.body) {
                    const payload = JSON.parse(config.body);
                    resource = `${LOCAL_BACKEND_URL}/wallet/withdraw`;
                    config.body = JSON.stringify({
                        amount: payload.amount,
                        bankInfo: payload
                    });
                }
            }
            // Intercept initial Mock endpoints to make UI load
            else if (resource.includes('/hall/api/lobby/site/getSiteInfo')) {
                resource = `${LOCAL_BACKEND_URL}/hall/api/lobby/site/getSiteInfo`;
            }
            else if (resource.includes('/hall/api/game/hall/hotListV2')) {
                resource = `${LOCAL_BACKEND_URL}/hall/api/game/hall/hotListV2`;
            }
            else if (resource.includes('/hall/api/lobby/publicityInfo/list')) {
                resource = `${LOCAL_BACKEND_URL}/hall/api/lobby/publicityInfo/list`;
            }
            else if (resource.includes('/hall/api/lobby/currencyInfo/getAllCurrency')) {
                resource = `${LOCAL_BACKEND_URL}/hall/api/lobby/currencyInfo/getAllCurrency`;
            }
            else if (resource.includes('/hall/api/lobby/webapi/forceUpdate/getForceUpdate')) {
                resource = `${LOCAL_BACKEND_URL}/hall/api/lobby/webapi/forceUpdate/getForceUpdate`;
            }
        }
        
        // Inject token if hitting our local backend
        if (resource.startsWith(LOCAL_BACKEND_URL) && localToken) {
            config = config || {};
            config.headers = config.headers || {};
            config.headers['Authorization'] = `Bearer ${localToken}`;
        }

        try {
            const response = await originalFetch(resource, config);
            
            // Intercept response to save token locally if logging in
            if (resource.includes('/auth/login') && response.clone) {
                const clone = response.clone();
                clone.json().then(data => {
                    if (data.code === 0 && data.data && data.data.token) {
                        localToken = data.data.token;
                        localStorage.setItem('local_auth_token', localToken);
                        console.log('Token intercepted and stored locally.');
                    }
                }).catch(e => console.error(e));
            }
            
            return response;
        } catch (e) {
            console.error('Fetch error in custom interceptor: ', e);
            throw e;
        }
    };
    
    // Intercept XHR similarly
    const originalXHR = window.XMLHttpRequest;
    function CustomXHR() {
        const xhr = new originalXHR();
        const originalOpen = xhr.open;
        xhr.open = function(method, url) {
            this._interceptedUrl = url;
            if (typeof url === 'string') {
                if (url.includes('/hall/api/account/login/')) url = `${LOCAL_BACKEND_URL}/auth/login`;
                else if (url.includes('/hall/api/account/register/')) url = `${LOCAL_BACKEND_URL}/auth/register`;
                else if (url.includes('/hall/api/account/getUserInfo')) url = `${LOCAL_BACKEND_URL}/auth/getUserInfo`;
                else if (url.includes('/hall/api/finance/pay/deposit')) url = `${LOCAL_BACKEND_URL}/wallet/deposit`;
                else if (url.includes('/hall/api/finance/pay/withdraw')) url = `${LOCAL_BACKEND_URL}/wallet/withdraw`;
                else if (url.includes('/hall/api/lobby/site/getSiteInfo')) url = `${LOCAL_BACKEND_URL}/hall/api/lobby/site/getSiteInfo`;
                else if (url.includes('/hall/api/game/hall/hotListV2')) url = `${LOCAL_BACKEND_URL}/hall/api/game/hall/hotListV2`;
                else if (url.includes('/hall/api/lobby/publicityInfo/list')) url = `${LOCAL_BACKEND_URL}/hall/api/lobby/publicityInfo/list`;
                else if (url.includes('/hall/api/lobby/currencyInfo/getAllCurrency')) url = `${LOCAL_BACKEND_URL}/hall/api/lobby/currencyInfo/getAllCurrency`;
                else if (url.includes('/hall/api/lobby/webapi/forceUpdate/getForceUpdate')) url = `${LOCAL_BACKEND_URL}/hall/api/lobby/webapi/forceUpdate/getForceUpdate`;
            }
            return originalOpen.apply(this, arguments);
        };
        
        const originalSend = xhr.send;
        xhr.send = function() {
             if (this._interceptedUrl && this._interceptedUrl.startsWith(LOCAL_BACKEND_URL) && localToken) {
                 this.setRequestHeader('Authorization', `Bearer ${localToken}`);
             }
             return originalSend.apply(this, arguments);
        };
        return xhr;
    }
    window.XMLHttpRequest = CustomXHR;

    console.log('🎰 Extended Custom Backend Interceptor Injected Successfully!');
})();
