// 🚀 NO777 - User Overlay, Balance, and Google Login Fix
// This script integrates Firebase Auth with the existing site and handles Dual-Sync.

(function() {
    const style = document.createElement('style');
    style.innerHTML = `
        #no777-user-overlay {
            position: fixed;
            bottom: 80px;
            right: 20px;
            z-index: 99999;
            background: linear-gradient(135deg, #f0c059, #d4a037);
            color: #874404;
            padding: 10px 15px;
            border-radius: 50px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.3);
            font-family: Arial, sans-serif;
            font-weight: bold;
            display: flex;
            align-items: center;
            gap: 10px;
            cursor: pointer;
            transition: transform 0.2s;
        }
        #no777-user-overlay:hover { transform: scale(1.05); }
        #no777-user-menu {
            position: fixed;
            bottom: 140px;
            right: 20px;
            z-index: 99998;
            background: #202329;
            color: white;
            border: 1px solid #313843;
            border-radius: 10px;
            width: 200px;
            display: none;
            flex-direction: column;
            overflow: hidden;
            box-shadow: 0 10px 25px rgba(0,0,0,0.5);
        }
        .user-menu-item {
            padding: 12px 15px;
            border-bottom: 1px solid #313843;
            cursor: pointer;
            font-size: 14px;
        }
        .user-menu-item:hover { background: #313843; }
        .user-menu-item.deposit { background: #04be02; color: white; font-weight: bold; }
    `;
    document.head.appendChild(style);

    const overlay = document.createElement('div');
    overlay.id = 'no777-user-overlay';
    overlay.innerHTML = `<span>Loading...</span>`;
    document.body.appendChild(overlay);

    const menu = document.createElement('div');
    menu.id = 'no777-user-menu';
    menu.innerHTML = `
        <div class="user-menu-item google-login" onclick="window.doGoogleLogin()" style="background:#4285F4; color:white; display:flex; align-items:center; gap:10px; font-weight:bold;">
            <img src="https://www.gstatic.com/images/branding/product/1x/gsa_512dp.png" width="20"> Login with Google
        </div>
        <div class=\"user-menu-item deposit\" onclick=\"location.href='/deposit.html'\">💰 DEPOSIT</div>
        <div class=\"user-menu-item\" id=\"logout-btn\">🚪 Logout</div>
    `;
    document.body.appendChild(menu);

    overlay.onclick = (e) => {
        e.stopPropagation();
        menu.style.display = menu.style.display === 'flex' ? 'none' : 'flex';
    };

    document.addEventListener('click', () => {
        menu.style.display = 'none';
    });

    menu.onclick = (e) => e.stopPropagation();

    // Firebase Auth Integration
    const updateUI = () => {
        const user = firebase.auth().currentUser;
        if (!user) {
            overlay.innerHTML = `🔑 Login / Register`;
            overlay.onclick = (e) => {
                e.stopPropagation();
                // Check if registration modal is already open, if not, try to trigger it
                const regBtn = document.getElementById('insideRegisterSubmitClick');
                if (regBtn) {
                     menu.style.display = menu.style.display === 'flex' ? 'none' : 'flex';
                } else {
                     // Site likely has its own buttons, just show menu for Google alternative
                     menu.style.display = menu.style.display === 'flex' ? 'none' : 'flex';
                }
            };
        } else {
            // Get Balance from Firestore
            firebase.firestore().collection('users').doc(user.email || user.uid).onSnapshot(doc => {
                const data = doc.data() || { balance: 0 };
                overlay.innerHTML = `🪙 Rs ${data.balance.toLocaleString()}`;
            });
            overlay.onclick = (e) => {
                e.stopPropagation();
                menu.style.display = menu.style.display === 'flex' ? 'none' : 'flex';
            };
        }
    };

    // 🚀 GOOGLE LOGIN LOGIC
    window.doGoogleLogin = () => {
        console.log("🎯 Initiating Google Login...");
        const provider = new firebase.auth.GoogleAuthProvider();
        firebase.auth().signInWithPopup(provider).then((result) => {
            const user = result.user;
            console.log('🎰 No777 Google Success:', user.email);
            // Sync Google user to Firestore
            firebase.firestore().collection('users').doc(user.email || user.uid).set({
                account: user.email,
                email: user.email,
                uid: user.uid,
                displayName: user.displayName,
                lastLogin: new Date().toISOString(),
                type: 'google',
                balance: 777 // Bonus for new registration
            }, { merge: true }).then(() => {
                location.reload();
            });
        }).catch((error) => {
            console.error('Google Auth Error:', error);
            if (error.code !== 'auth/popup-closed-by-user') {
                alert("Google Login failed: " + error.message);
            }
        });
    };

    // Wait for Firebase
    const checkFirebase = setInterval(() => {
        if (window.firebase && firebase.apps.length) {
            clearInterval(checkFirebase);
            firebase.auth().onAuthStateChanged(updateUI);
            const logoutBtn = document.getElementById('logout-btn');
            if (logoutBtn) {
                logoutBtn.onclick = () => {
                    firebase.auth().signOut().then(() => location.reload());
                };
            }
        }
    }, 500);

    // 🚀 BIND TO NATIVE BUTTONS
    const bindNativeButtons = () => {
        // Find Google button in local Register Modal
        const nativeGoogle = document.querySelector('.lobby-third-party-button--google');
        if (nativeGoogle && !nativeGoogle.dataset.bound) {
            console.log("🔗 Binding to native Google button...");
            nativeGoogle.style.cursor = 'pointer';
            nativeGoogle.addEventListener('click', (e) => {
                e.preventDefault();
                e.stopPropagation();
                window.doGoogleLogin();
            }, true); // Use capture to intercept
            nativeGoogle.dataset.bound = "true";
            
            // Overlay a transparent div if it's an iframe causing issues
            if (nativeGoogle.querySelector('iframe')) {
                const overlayDiv = document.createElement('div');
                overlayDiv.style = "position:absolute; top:0; left:0; width:100%; height:100%; z-index:9999; cursor:pointer;";
                overlayDiv.onclick = (e) => {
                    e.preventDefault();
                    e.stopPropagation();
                    window.doGoogleLogin();
                };
                nativeGoogle.style.position = 'relative';
                nativeGoogle.appendChild(overlayDiv);
            }
        }
    };

    const observer = new MutationObserver(bindNativeButtons);
    observer.observe(document.body, { childList: true, subtree: true });
    setInterval(bindNativeButtons, 1000); // Fail-safe fallback

})();
