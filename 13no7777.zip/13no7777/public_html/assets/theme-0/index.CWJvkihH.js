
        window.__MANIFEST_ASSETS = 'assets/theme-0/manifest.be77b755.json';
        import"./commonChunk.DiQG_QTc.js";import"./vendorChunk.DYJWRM33.js";import"../vendors/vendor-stable.B6V2PW6Q.js";const r=Object.freeze(Object.defineProperty({__proto__:null},Symbol.toStringTag,{value:"Module"}));export{r as t};
