/**
 * White-Label Interceptor v3 — FINAL
 * Triple-layer approach:
 * 1. Network intercept (XHR + Fetch) — mock all domain-check APIs
 * 2. Runtime domain store patch — null out the check function after app loads
 * 3. MutationObserver — remove any popup DOM elements if they appear
 */
(function() {
    'use strict';

    // ─── LAYER 1: Network-level mock ─────────────────────────────────────────
    // These are all the API endpoints that the app calls to check domain/site health.
    // We return success responses so the app never triggers a 'domain banned' state.
    const BLOCKED_APIS = [
        '/api/common/domain/status',
        '/api/common/domain',
        '/api/domain/lobby',
        '/api/statistics/domain',
        '/api/gohal/heartbeat',
        '/api/gohal/getSysInfo',
        '/api/lobby/site/getSiteInfo',
    ];

    // Build success mock response for each URL
    function buildMockResponse(url) {
        const injected = window.LOBBY_SITE_CONFIG?.INJECT_DATA;
        if (url.includes('getSiteInfo')) {
            return {
                code: 1, msg: 'success',
                data: {
                    ...(injected?.apiGetSiteInfo?.data?.data || {}),
                    site_status: 0,
                    status: 0,
                    maintainStatus: 0,
                    limitStatus: 0,
                    isBanned: false,
                    isExpired: false,
                    sBanned: false,
                }
            };
        }
        if (url.includes('getSysInfo')) {
            return {
                code: 1, msg: 'success',
                data: {
                    ...(injected?.apiGetSystemStatus?.data?.data || {}),
                    site_status: 0,
                    status: 0,
                }
            };
        }
        if (url.includes('heartbeat')) {
            return { code: 1, msg: 'success', data: true };
        }
        // Default success for any domain/status endpoint
        return {
            code: 1, msg: 'success',
            data: {
                status: 0,
                site_status: 0,
                isBanned: false,
                isExpired: false,
                sBanned: false,
                maintainStatus: 0,
                limitStatus: 0,
            }
        };
    }

    function isBlocked(url) {
        if (!url) return false;
        url = url.toString();
        return BLOCKED_APIS.some(api => url.includes(api));
    }

    // Intercept XHR
    const _open = XMLHttpRequest.prototype.open;
    const _send = XMLHttpRequest.prototype.send;

    XMLHttpRequest.prototype.open = function(method, url) {
        this._wl_url = url ? url.toString() : '';
        return _open.apply(this, arguments);
    };

    XMLHttpRequest.prototype.send = function(body) {
        if (isBlocked(this._wl_url)) {
            const self = this;
            const mockData = JSON.stringify(buildMockResponse(this._wl_url));
            console.log('[WL] Mocked XHR:', self._wl_url);

            // Use setTimeout to ensure event handlers are registered first
            setTimeout(function() {
                try {
                    Object.defineProperty(self, 'readyState', { get: function() { return 4; }, configurable: true });
                    Object.defineProperty(self, 'status', { get: function() { return 200; }, configurable: true });
                    Object.defineProperty(self, 'responseText', { get: function() { return mockData; }, configurable: true });
                    Object.defineProperty(self, 'response', { get: function() { return mockData; }, configurable: true });
                } catch(e) {}
                self.dispatchEvent(new ProgressEvent('readystatechange'));
                self.dispatchEvent(new ProgressEvent('load'));
                self.dispatchEvent(new ProgressEvent('loadend'));
            }, 0);
            return;
        }
        return _send.apply(this, arguments);
    };

    // Intercept Fetch
    const _fetch = window.fetch;
    if (_fetch) {
        window.fetch = function(resource, init) {
            const url = (resource && typeof resource === 'object' ? resource.url : resource) || '';
            if (isBlocked(url)) {
                console.log('[WL] Mocked Fetch:', url);
                const mockData = JSON.stringify(buildMockResponse(url));
                return Promise.resolve(new Response(mockData, {
                    status: 200,
                    headers: { 'Content-Type': 'application/json' }
                }));
            }
            return _fetch.apply(this, arguments);
        };
    }

    // ─── LAYER 2: Runtime store patch ────────────────────────────────────────
    // After the app initializes, null out the domain-check functions in Pinia stores.
    // We repeatedly try for 10 seconds in case the app loads slowly.
    let patchAttempts = 0;
    const patchInterval = setInterval(function() {
        patchAttempts++;
        if (patchAttempts > 100) { clearInterval(patchInterval); return; }

        try {
            // Try to access the Pinia store directly
            const win = window;
            // Null out any domain check scheduler
            if (win.__pinia) {
                const stores = win.__pinia._s;
                if (stores) {
                    stores.forEach(function(store) {
                        // Look for domain-related actions
                        if (store.$id && store.$id.toLowerCase().includes('domain')) {
                            console.log('[WL] Patching domain store:', store.$id);
                            // Override all actions to no-ops
                            Object.keys(store).forEach(function(key) {
                                if (typeof store[key] === 'function' && 
                                    (key.includes('check') || key.includes('domain') || key.includes('status') || key.includes('ban'))) {
                                    console.log('[WL] Replacing store action:', store.$id + '.' + key);
                                    store[key] = function() { return Promise.resolve({ code: 1, data: { status: 0, isBanned: false } }); };
                                }
                            });
                        }
                    });
                }
            }
        } catch(e) {}
    }, 100);

    // ─── LAYER 3: DOM popup destroyer ────────────────────────────────────────
    // If the popup dialog ever appears in the DOM, immediately remove it.
    const POPUP_TEXT_TRIGGERS = [
        'main hall', 'backup line', 'switch lines', 'domain', 'banned',
        'Sorry', 'switchdomain', 'keepdomain'
    ];

    function killPopup() {
        // Find and kill any modal/dialog that contains domain-related text
        const dialogs = document.querySelectorAll('[class*="dialog"], [class*="modal"], [class*="popup"], [role="dialog"]');
        dialogs.forEach(function(el) {
            const text = (el.textContent || '').toLowerCase();
            if (POPUP_TEXT_TRIGGERS.some(t => text.includes(t.toLowerCase()))) {
                console.log('[WL] Destroying popup:', text.substring(0, 80));
                el.remove();
                // Also remove any overlay/backdrop
                document.querySelectorAll('[class*="overlay"], [class*="mask"], [class*="backdrop"]').forEach(function(o) {
                    if (o.style.display !== 'none') o.remove();
                });
            }
        });
    }

    // Run popup killer every 200ms for 30 seconds after page load
    document.addEventListener('DOMContentLoaded', function() {
        const killInterval = setInterval(function() { killPopup(); }, 200);
        setTimeout(function() { clearInterval(killInterval); }, 30000);
    });

    // Also use MutationObserver for real-time popup removal
    const observer = new MutationObserver(function(mutations) {
        mutations.forEach(function(mutation) {
            mutation.addedNodes.forEach(function(node) {
                if (node.nodeType === 1) {
                    const text = (node.textContent || '').toLowerCase();
                    if (POPUP_TEXT_TRIGGERS.some(t => text.includes(t.toLowerCase()))) {
                        const classStr = (node.className || '').toLowerCase();
                        if (classStr.includes('dialog') || classStr.includes('modal') || 
                            classStr.includes('popup') || node.getAttribute('role') === 'dialog') {
                            console.log('[WL] Mutation popup destroyed:', text.substring(0, 80));
                            node.remove();
                        }
                    }
                }
            });
        });
    });

    // Start observing once DOM is ready
    if (document.body) {
        observer.observe(document.body, { childList: true, subtree: true });
    } else {
        document.addEventListener('DOMContentLoaded', function() {
            observer.observe(document.body, { childList: true, subtree: true });
        });
    }

    console.log('[White-Label] v3 FINAL — Triple protection active. Domain checks permanently disabled.');
})();
