<?php
header('Content-Type: application/json');
$file = 'deposit_accounts.json';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = file_get_contents('php://input');
    $json = json_decode($data, true);
    if ($json) {
        file_put_contents($file, json_encode($json));
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false, 'error' => 'Invalid JSON']);
    }
} else {
    if (file_exists($file)) {
        echo file_get_contents($file);
    } else {
        echo json_encode([
            "jazzCashName" => "TASLEEM BIBI",
            "jazzCashNumber" => "03278879927",
            "easyPaisaName" => "SHAMSHAD",
            "easyPaisaNumber" => "03485021854"
        ]);
    }
}
?>
