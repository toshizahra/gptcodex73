<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');

// Receive JSON input
$input = json_decode(file_get_contents('php://input'), true);

if (!$input) {
    echo json_encode(['success' => false, 'message' => 'Invalid input']);
    exit;
}

$userAccount = $input['account'] ?? 'Unknown';
$amount = $input['amount'] ?? 0;
$method = $input['method'] ?? 'Unknown';
$tid = $input['transactionId'] ?? 'N/A';
$screenshotBase64 = $input['screenshot'] ?? ''; // This is the data:image/png;base64,... string

$to = "saeedzulfiqar242@gmail.com";
$admin_from = "support@cheaper360.store";
$subject = "New Deposit Request - PKR $amount ($userAccount)";

// SMTP Configuration (From previous session discovery)
$smtp = [
    'host' => 'ssl://smtp.hostinger.com',
    'port' => 465,
    'user' => 'support@cheaper360.store',
    'pass' => '@Idea241@'
];

function sendEmailWithAttachment($to, $subject, $userAccount, $amount, $method, $tid, $base64Data, $smtp) {
    $boundary = md5(time());
    $c = "\r\n";

    // Prepare message body
    $body = "
    <html>
    <body style='font-family: Arial, sans-serif; line-height: 1.6; color: #333;'>
        <h2 style='color: #d4a017;'>New Deposit Request</h2>
        <p><strong>User Account:</strong> $userAccount</p>
        <p><strong>Amount:</strong> PKR $amount</p>
        <p><strong>Method:</strong> $method</p>
        <p><strong>Transaction ID:</strong> $tid</p>
        <p style='color: #e74c3c;'><em>Please verify the screenshot attached or below.</em></p>
        <hr>
        <p style='font-size: 12px; color: #777;'>Sent via NO777 Manual Deposit System</p>
    </body>
    </html>";

    // Headers
    $headers = "From: NO777 Admin <" . $smtp['user'] . ">\r\n";
    $headers .= "Reply-To: " . $smtp['user'] . "\r\n";
    $headers .= "MIME-Version: 1.0\r\n";
    $headers .= "Content-Type: multipart/mixed; boundary=\"$boundary\"\r\n";

    // Multipart body
    $message = "--$boundary\r\n";
    $message .= "Content-Type: text/html; charset=UTF-8\r\n";
    $message .= "Content-Transfer-Encoding: 7bit\r\n\r\n";
    $message .= $body . "\r\n\r\n";

    // Attachment
    if ($base64Data) {
        // Extract content type and data
        if (preg_match('/^data:image\/(\w+);base64,(.+)$/', $base64Data, $matches)) {
            $ext = $matches[1];
            $data = $matches[2];
            $message .= "--$boundary\r\n";
            $message .= "Content-Type: image/$ext; name=\"screenshot.$ext\"\r\n";
            $message .= "Content-Description: screenshot.$ext\r\n";
            $message .= "Content-Disposition: attachment; filename=\"screenshot.$ext\"; size=" . strlen(base64_decode($data)) . ";\r\n";
            $message .= "Content-Transfer-Encoding: base64\r\n\r\n";
            $message .= chunk_split($data) . "\r\n\r\n";
        }
    }
    $message .= "--$boundary--";

    // SMTP sending via fsockopen (since mail() might be blocked/limited)
    $socket = fsockopen($smtp['host'], $smtp['port'], $errno, $errstr, 10);
    if (!$socket) return "Connection failed: $errstr";

    function read($s) { $data = ""; while($str = fgets($s, 515)) { $data .= $str; if(substr($str, 3, 1) == " ") break; } return $data; }

    read($socket);
    fputs($socket, "EHLO " . $_SERVER['SERVER_NAME'] . $c); read($socket);
    fputs($socket, "AUTH LOGIN" . $c); read($socket);
    fputs($socket, base64_encode($smtp['user']) . $c); read($socket);
    fputs($socket, base64_encode($smtp['pass']) . $c); $auth = read($socket);

    if (strpos($auth, '235') === false) return "Auth failed: $auth";

    fputs($socket, "MAIL FROM: <" . $smtp['user'] . ">" . $c); read($socket);
    fputs($socket, "RCPT TO: <$to>" . $c); read($socket);
    fputs($socket, "DATA" . $c); read($socket);
    fputs($socket, "To: $to\r\nSubject: $subject\r\n$headers\r\n\r\n$message\r\n.\r\n");
    $resp = read($socket);
    fputs($socket, "QUIT" . $c);
    fclose($socket);

    return (strpos($resp, '250') !== false) ? true : "Final SEND failed: $resp";
}

$result = sendEmailWithAttachment($to, $subject, $userAccount, $amount, $method, $tid, $screenshotBase64, $smtp);

if ($result === true) {
    echo json_encode(['success' => true]);
} else {
    echo json_encode(['success' => false, 'message' => $result]);
}
?>
