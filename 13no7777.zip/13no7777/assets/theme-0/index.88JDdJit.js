
        window.__MANIFEST_ASSETS = 'assets/theme-0/manifest.5b8aca7b.json';
        import"./commonChunk.B7x9OVuc.js";import"./vendorChunk.ePHpEYkX.js";import"../vendors/vendor-stable.mi1TSsWS.js";const r=Object.freeze(Object.defineProperty({__proto__:null},Symbol.toStringTag,{value:"Module"}));export{r as t};
