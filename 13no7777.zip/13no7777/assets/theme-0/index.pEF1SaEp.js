import{a9 as t}from"./commonChunk.B7x9OVuc.js";import{a as o}from"./CollapseItem.DO4MDvV0.js";const r=t(o);export{r as C};
