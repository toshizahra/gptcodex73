import{a9 as t}from"./commonChunk.B7x9OVuc.js";import{C as e}from"./CollapseItem.DO4MDvV0.js";const m=t(e);export{m as C};
