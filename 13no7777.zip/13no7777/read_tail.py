
import os

filepath = r'e:\PROJECTS\13no7777\index.html'
with open(filepath, 'rb') as f:
    lines = f.readlines()

print(f'Total lines: {len(lines)}')
for i, line in enumerate(lines[-15:]):
    ln = len(lines) - 15 + i + 1
    content = line.decode('utf-8', errors='ignore').strip()
    print(f'Line {ln} ({len(line)} bytes): {content}')
