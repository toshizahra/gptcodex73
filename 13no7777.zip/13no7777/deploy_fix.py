import ftplib
import os

FTP_HOST = "82.25.83.158"
FTP_USER = "u916646072.13no7777.com"
FTP_PASS = "@Idea241@"

FILES_TO_UPLOAD = [
    r"e:\PROJECTS\13no7777\public_html\ci.js",
    r"e:\PROJECTS\13no7777\public_html\index.html",
    r"e:\PROJECTS\13no7777\public_html\user-overlay.js",
    r"e:\PROJECTS\13no7777\public_html\.htaccess"
]

def deploy():
    try:
        print(f"Connecting to {FTP_HOST}...")
        ftp = ftplib.FTP(FTP_HOST)
        ftp.login(FTP_USER, FTP_PASS)
        print("Logged in. Listing current directory:")
        ftp.dir()

        # Cleanup known corrupted files
        try:
            ftp.delete("custom-intercepphp.js")
            print("Deleted corrupted file: custom-intercepphp.js")
        except:
            pass

        try:
            ftp.delete("profile.html")
            print("Deleted profile.html from server")
        except:
            pass

        for local_path in FILES_TO_UPLOAD:
            filename = os.path.basename(local_path)
            with open(local_path, "rb") as f:
                print(f"Uploading {filename}...")
                ftp.storbinary(f"STOR {filename}", f)
                print(f"Successfully uploaded {filename}")

        # Try to delete the misnamed file if it exists
        try:
            print("Attempting to delete custom-intercepphp.js...")
            ftp.delete("custom-intercepphp.js")
            print("Deleted custom-intercepphp.js")
        except:
            print("Could not delete custom-intercepphp.js (might not exist)")

        ftp.quit()
        print("Deployment finished successfully!")
    except Exception as e:
        print(f"Error during deployment: {e}")

if __name__ == "__main__":
    deploy()
