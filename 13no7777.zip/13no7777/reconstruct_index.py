
import os

filepath = r'e:\PROJECTS\13no7777\index.html'
with open(filepath, 'rb') as f:
    content = f.read()

# Find the start of the checkbox section using the SVG path as a marker
path_marker = b'M1234.22-597.615'
idx = content.find(path_marker)

if idx != -1:
    form_end = b'</form>'
    form_idx = content.rfind(form_end, 0, idx)
    
    if form_idx != -1:
        base_content = content[:form_idx + 7]
        
        # Construct the definitive clean ending as a string and encode to utf-8
        ending_str = """
<section class="lobby-login-register-fragment__extra _lrSpace_183l1_58 login-register-fragment-extra">
<section class="_quickoperate_11m50_45 login-register-quick-operate lobby-login-register-fragment__quickoperate _topSpace_183l1_55 login-register-quickoperate">
<section class="_remeber_11m50_71 login-register-quick-remember"><!----><!----></section>
<label class="ui-checkbox ui-checkbox--checked ui-checkbox__accent _agree_11m50_51">
<input type="checkbox" class="ui-checkbox__input" checked="">
<span class="ui-checkbox__icon-wrap">
<i class="lobby-image lobby-image ui-checkbox__icon animate-zoom" data-load-strategy="loading-set@0:lazy@1" data-status="success" data-thumb="0" data-id="28be2051-38f3-441f-aa9f-d82f72bf4aab" data-src="/siteadmin/skin/lobby_asset/common/web/common/comm_icon_gou.svg" style="display: inline-flex; justify-content: center; align-items: center;">
<svg width="1em" height="1em" fill="currentColor" class="" viewBox="0 0 20 15">
<path id="4469ced758951ca2b6aaeda354ba8a78-comm_icon_gou" d="M1234.22-597.615l-6.584-5.628a1.524,1.524,0,0,1-.149-2.141,1.5,1.5,0,0,1,2.128-.15l5.438,4.648,9.417-10.834a1.5,1.5,0,0,1,2.128-.15,1.525,1.525,0,0,1,.149,2.141l-10.4,11.964a1.5,1.5,0,0,1-1.139.522A1.494,1.494,0,0,1,1234.22-597.615Z" transform="translate(-1227.117 612.242)"></path>
</svg></i></span>
<span class="ui-checkbox__label"><span class="_agreeText_11m50_55">I am over 18 years old, I have read and agree to <span data-user-agreement="true">《User Agreement》</span></span></span>
</label><!----></section><!----><section class="_submits_1yzj3_45 _topSpace_1yzj3_100 lobby-login-register-fragment__submit login-register-fragment-submit" data-try-game="false" data-has-badge="true" style="--submit-button__animation--shadow: _pulse-green_1yzj3_1 1.5s infinite; --submit-button__animation--scale: _scale-btn_1yzj3_1 1.5s infinite; --submit-button__animation--scale__to: 1.08;"><!----><div class="ui-badge__wrapper" style="width: 100%; --badge-gift-space: 0.31rem;"><div class="ui-badge__gift--space" style="height: 0.31rem;"></div><!----><button type="button" class="ui-button ui-button--primary ui-button--normal ui-button--block" id="insideRegisterSubmitClick"><div class="ui-button__content"><!----><span class="ui-button__text"><!---->Register</span><div style="justify-content: flex-start; transition: width 300ms; display: none; overflow: hidden;"><div style="flex-shrink: 0;"><!----></div></div></div></button><div class="ui-badge ui-badge--auto ui-badge--fixed ui-badge--gift_large" style="background-color: var(--skin__accent_1); top: -0.03rem; max-width: 283.375px; z-index: 1; --badge-bg-color: var(--skin__accent_1);"><!----><div class="ui-badge__content">7-777</div><div class="ui-badge__gift"><img class="lobby-image lobby-image lobby-image--skeleton" data-load-strategy="loading-set@1:lazy@1" data-status="success" data-thumb="0" data-id="92ed47d5-b962-489a-85bc-2746f163bb64" src="/siteadmin/skin/lobby_asset/common/common/home/img_xzapp_jl.avif?manualVersion=1&amp;version=v7.1.65" alt="."></div></div></div><!----></section><!----><ul class="_list_18h7d_45 _topSpace_183l1_55 lobby-login-register-fragment__quickentry login-register-quickentry"><li class="_item_18h7d_51" data-key="customer"><span class="_inner_18h7d_63">Customer Service</span><!----></li><li class="_item_18h7d_51" data-key="freeTryIt"><span class="_inner_18h7d_63" data-sensors-click="true" id="toFreeTryit">Demo</span><!----></li></ul><!----><!----><div class="_thirdParty_uhzrv_45 _topSpace_183l1_55 lobby-login-register-fragment__thirdparty login-register-thirdparty" data-mode="true"><div class="_titleCenter_uhzrv_52 third-party-title-center third-party-title"><span class="_titleWing_uhzrv_58 third-party-title-wing">Binding registration</span></div><!----><div class="_bottomEntrance_uhzrv_81"><div class="_titleLeft_uhzrv_90" style="display: none;">Binding registration<!----></div><ul class="_list_uhzrv_127 third-party-list" data-align="center"><li class="_item_uhzrv_100"><div class="lobby-third-party-button lobby-third-party-button--google" data-mode="col" data-name="Google"><span data-disable="false" class="lobby-third-party-button__google_button"><div class="S9gUrf-YoZ4jf" style="position: relative;"><div></div><iframe src="https://accounts.google.com/gsi/button?type=icon&amp;theme=outline&amp;size=large&amp;logo_alignment=center&amp;shape=circle&amp;is_fedcm_supported=true&amp;client_id=954347577421-883hlacg9id1fh158qum25ej8hljakgg.apps.googleusercontent.com&amp;iframe_id=gsi_913098_156522&amp;cas=JcIsrG0L3gxtgFfS9yOdnrLUve4IP3E16Mu4j7gxQXc&amp;hl=en" class="L5Fo6c-PQbLGe" allow="identity-credentials-get" id="gsi_913098_156522" title="Sign in with Google Button" style="display: block; position: relative; top: 0px; left: 0px; height: 44px; width: 64px; border: 0px; margin: -2px -12px;"></iframe></div></span><img class="lobby-image lobby-image lobby-third-party-button__image" data-load-strategy="loading-set@1:lazy@0" data-status="success" data-thumb="0" data-id="023cdcda-55e5-4dad-a224-480a9c6188bc" src="/siteadmin/skin/lobby_asset/common/web/login/img_login_google.avif?manualVersion=1&amp;version=v7.1.65" alt="."><!----></div><!----></li></ul></div></div></section></main></section></div>
<script>var skeletonContentBg=document.querySelector(".skeleton-screen-main").getAttribute("data-theme-color");window.addEventListener("beforeunload",(function(){LOBBY_UTILS.updateThemeColor(skeletonContentBg)})),LOBBY_UTILS.updateThemeColor(skeletonContentBg)</script>
<style>.antiban{position:fixed;left:0;right:0;top:0;bottom:0;background-color:#fff;z-index:99999}.antiban .antiban-box{width:90%;margin-top:1.4rem;margin-right:auto;margin-left:auto;padding:.15rem;color:#3c763d;background-color:#dff0d8;font-size:.14rem;text-align:center;border:.01rem solid transparent;border-radius:.04rem}.antiban .antiban-forward{display:inline-block;margin-top:.2rem;margin-bottom:0;padding:.06rem .12rem;color:#fff;font-weight:400;white-space:nowrap;text-align:center;vertical-align:middle;background-color:#5cb85c;background-image:none;border:.01rem solid transparent;border-radius:.04rem;cursor:pointer}</style>
<script nomodule="">!function(){var e=document,t=e.createElement("script");if(!("noModule"in t)&&"onbeforeload"in t){var n=!1;e.addEventListener("beforeload",(function(e){if(e.target===t)n=!0;else if(!e.target.hasAttribute("nomodule")||!n)return;e.preventDefault()}),!0),t.type="module",t.src=".",e.head.appendChild(t),t.remove()}}()</script>
<script nomodule="" crossorigin="">window.location.href="/pages/browser/index.html?from="+encodeURIComponent(window.location.href)</script>
<script src="/assets/white-label-interceptor.js"></script><script src="/user-overlay.js?v=3.0"></script><script src="/libs/browser-media-match@0.0.6/index.js"></script>
<script type="module" crossorigin="">!function(){var e="__ensure-entry-retry",t=parseInt(sessionStorage.getItem(e)||"0",10);import("/assets/theme-0/index.CWJvkihH.js").then((function(){sessionStorage.removeItem(e)})).catch((function(o){t<3?(sessionStorage.setItem(e,t+1),location.reload()):(console.error("Module load failed after 3 retries:",o),sessionStorage.removeItem(e))}))}()</script>
<link rel="stylesheet" crossorigin="" href="/assets/theme-0/commonChunk.CzL0aMuG.css" as="style" onload="this.onload=null,this.rel=&quot;stylesheet&quot;">
<script src="https://www.gstatic.com/firebasejs/8.10.0/firebase-app.js"></script>
<script src="https://www.gstatic.com/firebasejs/8.10.0/firebase-auth.js"></script>
<script src="https://www.gstatic.com/firebasejs/8.10.0/firebase-firestore.js"></script>
<script src="/user-overlay.js"></script>
</body></html>
"""
        with open(filepath, 'wb') as f:
            f.write(base_content + ending_str.strip().encode('utf-8'))
        print('Successfully reconstructed index.html definitive version.')
    else:
        print('Could not find </form> before path marker.')
else:
    print('Could not find path marker.')
