import ftplib

FTP_HOST = "82.25.83.158"
FTP_USER = "u916646072.13no7777.com"
FTP_PASS = "@Idea241@"

def list_recursive(ftp, path="."):
    print(f"\n--- Listing {path} ---")
    try:
        items = []
        ftp.dir(path, items.append)
        for item in items:
            print(item)
            # Simple check for directory in MLSD-like or LIST output
            if item.startswith('d'):
                name = item.split()[-1]
                if name not in ['.', '..']:
                    list_recursive(ftp, f"{path}/{name}")
    except Exception as e:
        print(f"Error listing {path}: {e}")

def explore():
    try:
        print(f"Connecting to {FTP_HOST}...")
        with ftplib.FTP(FTP_HOST) as ftp:
            ftp.login(FTP_USER, FTP_PASS)
            print("Logged in successfully.")
            list_recursive(ftp)
    except Exception as e:
        print(f"Error: {e}")

if __name__ == "__main__":
    explore()
