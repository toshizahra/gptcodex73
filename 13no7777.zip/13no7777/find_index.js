const fs = require('fs');
const filePath = 'h:/error/public_html/assets/theme-0/commonChunk.DiQG_QTc.js';
const data = fs.readFileSync(filePath, 'utf8');
const searchStr = 'domainIsBaned';
let index = data.indexOf(searchStr);
while (index !== -1) {
    console.log(`Match at index ${index}:`);
    console.log(data.substring(index - 100, index + 200));
    console.log('-------------------');
    index = data.indexOf(searchStr, index + 1);
}
