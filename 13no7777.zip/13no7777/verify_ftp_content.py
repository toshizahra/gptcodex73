import ftplib
import os

FTP_HOST = "82.25.83.158"
FTP_USER = "u916646072.13no7777.com"
FTP_PASS = "@Idea241@"

def verify():
    with ftplib.FTP(FTP_HOST) as ftp:
        ftp.login(FTP_USER, FTP_PASS)
        print("Logged in.")
        
        files = ["ci.js", "index.html"]
        for f in files:
            print(f"\n--- Checking {f} ---")
            try:
                ftp.retrlines(f"RETR {f}", lambda line: print(line[:100] + ("..." if len(line) > 100 else "")))
            except Exception as e:
                print(f"Error reading {f}: {e}")

if __name__ == "__main__":
    verify()
