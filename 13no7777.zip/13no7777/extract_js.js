const fs = require('fs');
const filePath = 'h:/error/public_html/assets/theme-0/commonChunk.DiQG_QTc.js';
const data = fs.readFileSync(filePath, 'utf8');
const searchStr = 'domainIsBaned';
const index = data.indexOf(searchStr);

if (index !== -1) {
    // Look for previous '{' that starts the object or function
    let start = index;
    let balance = 0;
    // Walk back to find the start of the function or object
    // For minified code, we might just want a large chunk around it
    console.log(data.substring(index - 2000, index + 2000));
}
