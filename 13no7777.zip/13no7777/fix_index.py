
import os

filepath = r'e:\PROJECTS\13no7777\index.html'
with open(filepath, 'rb') as f:
    content = f.read()

# Find the last occurrence of the skeleton theme color script as a safe cut-off point.
marker = b'LOBBY_UTILS.updateThemeColor(skeletonContentBg)'
idx = content.rfind(marker)
if idx != -1:
    # Find the end of that script tag
    script_end = content.find(b'</script>', idx)
    if script_end != -1:
        base_content = content[:script_end + 9]
        
        # Now append the clean ending
        ending = b"""
 <style>.antiban{position:fixed;left:0;right:0;top:0;bottom:0;background-color:#fff;z-index:99999}.antiban .antiban-box{width:90%;margin-top:1.4rem;margin-right:auto;margin-left:auto;padding:.15rem;color:#3c763d;background-color:#dff0d8;font-size:.14rem;text-align:center;border:.01rem solid transparent;border-radius:.04rem}.antiban .antiban-forward{display:inline-block;margin-top:.2rem;margin-bottom:0;padding:.06rem .12rem;color:#fff;font-weight:400;white-space:nowrap;text-align:center;vertical-align:middle;background-color:#5cb85c;background-image:none;border:.01rem solid transparent;border-radius:.04rem;cursor:pointer}</style> 
 <script nomodule="">!function(){var e=document,t=e.createElement("script");if(!("noModule"in t)&&"onbeforeload"in t){var n=!1;e.addEventListener("beforeload",(function(e){if(e.target===t)n=!0;else if(!e.target.hasAttribute("nomodule")||!n)return;e.preventDefault()}),!0),t.type="module",t.src=".",e.head.appendChild(t),t.remove()}}()</script>
 <script nomodule="" crossorigin="">window.location.href="/pages/browser/index.html?from="+encodeURIComponent(window.location.href)</script>
 <script src="/assets/white-label-interceptor.js"></script>
 <script src="/user-overlay.js?v=3.0"></script>
 <script src="/libs/browser-media-match@0.0.6/index.js"></script>
 <script type="module" crossorigin="">!function(){var e="__ensure-entry-retry",t=parseInt(sessionStorage.getItem(e)||"0",10);import("/assets/theme-0/index.CWJvkihH.js").then((function(){sessionStorage.removeItem(e)})).catch((function(o){t<3?(sessionStorage.setItem(e,t+1),location.reload()):(console.error("Module load failed after 3 retries:",o),sessionStorage.removeItem(e))}))}()</script>
 <link rel="stylesheet" crossorigin="" href="/assets/theme-0/commonChunk.CzL0aMuG.css" as="style" onload="this.onload=null,this.rel=&quot;stylesheet&quot;">
 <script src="https://www.gstatic.com/firebasejs/8.10.0/firebase-app.js"></script>
 <script src="https://www.gstatic.com/firebasejs/8.10.0/firebase-auth.js"></script>
 <script src="https://www.gstatic.com/firebasejs/8.10.0/firebase-firestore.js"></script>
 <script src="/user-overlay.js"></script>
 </body>
 </html>
"""
        with open(filepath, 'wb') as f:
            f.write(base_content + ending)
        print('Successfully fixed index.html end.')
    else:
        print('Could not find </script> after marker.')
else:
    print('Could not find marker.')
