import ftplib

FTP_HOST = "82.25.83.158"
FTP_USER = "u916646072.13no7777.com"
FTP_PASS = "@Idea241@"

def check_structure():
    try:
        with ftplib.FTP(FTP_HOST) as ftp:
            ftp.login(FTP_USER, FTP_PASS)
            print("Logged in.")
            
            print("\nROOT LISTING:")
            files = []
            ftp.retrlines('LIST', files.append)
            for f in files:
                print(f)
            
            # Check for public_html explicitly
            try:
                ftp.cwd("public_html")
                print("\nSUCCESS: public_html exists as a subdirectory.")
                print("LISTING INSIDE public_html:")
                inner_files = []
                ftp.retrlines('LIST', inner_files.append)
                for f in inner_files:
                    print(f)
            except:
                print("\nINFO: public_html NOT found as a subdirectory.")

    except Exception as e:
        print(f"Error: {e}")

if __name__ == "__main__":
    check_structure()
