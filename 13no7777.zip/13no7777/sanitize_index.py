
import os

filepath = r'e:\PROJECTS\13no7777\index.html'
with open(filepath, 'rb') as f:
    content = f.read()

print(f'Original size: {len(content)}')

# Remove NULL bytes
null_count = content.count(b'\x00')
if null_count > 0:
    content = content.replace(b'\x00', b' ')
    print(f'Removed {null_count} NULL bytes.')

# Find the first </body></html> and keep only what is before it.
# This should remove any trailing junk appended by mistake.
end_marker = b'</body></html>'
idx = content.find(end_marker)
if idx != -1:
    content = content[:idx + len(end_marker)]
    print(f'Truncated at offset {idx}.')

# Also fix the known broken SVG path if it's still broken
# d="M1234.22-597.6
# We know the full string should be M1234.22-597.615...
search_broken = b'd="M1234.22-597.6'
if search_broken in content:
    # Let's find the closing quote and path tag
    pass # If we truncate at the first </body></html>, we might have already fixed it if the duplication was the cause.

with open(filepath, 'wb') as f:
    f.write(content)

print(f'Fixed file size: {len(content)}')
